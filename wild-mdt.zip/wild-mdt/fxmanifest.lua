-- Made by distritic

-- Converted By Wild

fx_version 'adamant'
game 'gta5'

ui_page "ui/index.html"

files {
    "ui/index.html",
    "ui/vue.min.js",
    "ui/script.js",
    "ui/main.css",
    "ui/styles/police.css",
    "ui/badges/police.png",
    "ui/footer.png",
    "ui/mugshot.png"
}

server_scripts {
    'serverCallbackLib/server.lua',
    '@vrp/lib/utils.lua',
    '@async/async.lua',
    '@mysql-async/lib/MySQL.lua',
    "sv_mdt.lua",
    "sv_vehcolors.lua",
    "config.lua"
}

client_scripts {
    'serverCallbackLib/server.lua',
    'config.lua',
    'cl_mdt.lua'
}

