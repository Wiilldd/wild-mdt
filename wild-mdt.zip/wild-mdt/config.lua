-- Made by distritic

-- Converted By Wild

config = {}

config.requiedjob = "Politi-Job"